@extends('layout')
@section('content')
		<!--end header -->
		@stop
	